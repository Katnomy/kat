src = '../static/package-lock.json';
integrity = src.integrity;